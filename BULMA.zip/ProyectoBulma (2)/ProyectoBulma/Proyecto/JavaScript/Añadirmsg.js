    document.getElementById('post-comment-button').addEventListener('click', function () {
        const commentText = document.getElementById('new-comment').value;
        
        if (commentText.trim() !== '') {
            const newComment = document.createElement('article');
            newComment.classList.add('media');

            const commentHTML = `
                <figure class="media-left">
                    <p class="image is-64x64">
                        <img src="../Img/Header/fotoPerfil.png" />
                    </p>
                </figure>
                <div class="media-content">
                    <div class="content">
                        <p>
                            <strong>Your Name</strong>
                            <br />
                            ${commentText}
                            <br />
                            <small><a>Like</a> · <a>Reply</a> · Just now</small>
                        </p>
                    </div>
                </div>
            `;

            newComment.innerHTML = commentHTML;

            const footer = document.querySelector('.footers');
            
            const commentArea = document.getElementById('new-comment');
            footer.insertBefore(newComment, commentArea.closest('article'));

            document.getElementById('new-comment').value = '';
        } else {
          
        }
    });