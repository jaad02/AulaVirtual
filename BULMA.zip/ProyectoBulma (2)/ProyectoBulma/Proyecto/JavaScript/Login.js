document.querySelector("button").addEventListener("click", () => {

    if (document.getElementById("usuario").value != "admin") {

        document.querySelectorAll("input").forEach(e => {
            e.classList.add("imputError")
        })

        let iconos = [...document.getElementsByClassName("iconoError")]
        iconos.forEach(e => {

            e.style.display = "block";

        })
    }
    else{
        window.location.href = "paginaInicio.html";
    }

})


