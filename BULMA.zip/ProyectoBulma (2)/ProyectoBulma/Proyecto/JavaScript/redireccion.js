document.addEventListener("DOMContentLoaded", function () {
   
    const imagenes = document.querySelectorAll(".imagenAsignatura");

   
    imagenes.forEach((imagen) => {
        imagen.addEventListener("click", function () {
           
            window.location.href = "paginaSeccion.html"; 
        });
    });

    const imagenes2 = document.querySelectorAll(".imagenAsignatura2");

   
    imagenes2.forEach((imagen) => {
        imagen.addEventListener("click", function () {
           
            window.location.href = "paginaSeccionError.html"; 
        });
    });

    const botonVolver = document.querySelectorAll(".botonVolver");
    botonVolver.forEach((imagen) => {
        imagen.addEventListener("click", function () {
           
            window.location.href = "paginaInicio.html"; 
        });
    }); 
});