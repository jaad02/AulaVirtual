document.addEventListener('DOMContentLoaded', () => {
  function openModal($el) {
    $el.classList.add('is-active');
  }

  function closeModal($el) {
    $el.classList.remove('is-active');
  }

  function closeAllModals() {
    document.querySelectorAll('.modal').forEach(($modal) => {
      closeModal($modal);
    });
  }

  // Agregar evento a todos los elementos con la clase 'js-modal-trigger'
  document.querySelectorAll('.js-modal-trigger').forEach(($trigger) => {
    const modalId = $trigger.dataset.target;
    const $modal = document.getElementById(modalId);

    if ($modal) {
      $trigger.addEventListener('click', () => {
        openModal($modal);
      });
    }
  });

  // Cerrar modal al hacer clic en el fondo, en el botón de cerrar o en los botones del footer del modal
  document.querySelectorAll('.modal-background, .buttonCancelar, .modal-card-foot .button')
    .forEach(($close) => {
      const $modal = $close.closest('.modal');

      $close.addEventListener('click', () => {
        closeModal($modal);
      });
    });

  // Cerrar modal con la tecla "Escape"
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
      closeAllModals();
    }
  });
});
  document.addEventListener("DOMContentLoaded", function () {
    const dropdown = document.getElementById("menu");
    const dropdownImg = document.getElementById("dropdown-img");

    dropdownImg.addEventListener("click", function () {
        dropdown.classList.toggle("is-active");
    });
});

