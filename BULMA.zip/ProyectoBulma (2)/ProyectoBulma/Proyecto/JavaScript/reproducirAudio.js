document.addEventListener("DOMContentLoaded", function () {
    // Control de sonido del icono en el header
    const audioIcono = document.querySelector(".audioIcono");
    const icono = document.querySelector(".iconoSonido .iconos");

    if (icono && audioIcono) {
        icono.addEventListener("click", function () {
            if (audioIcono.paused) {
                audioIcono.play();
            } else {
                audioIcono.pause();
            }
        });
    }

    // Control de sonidos en las asignaturas
    let cajas = document.querySelectorAll(".imagenSonidoEsquinaCajas");
    let audios = document.querySelectorAll(".imagenSonidoEsquinaCajas audio");

    cajas.forEach((caja) => {
        caja.addEventListener("click", function () {
            let audio = caja.querySelector("audio");

            // Pausar todos los demás audios antes de reproducir el nuevo
            audios.forEach((a) => {
                if (a !== audio) {
                    a.pause();
                    a.currentTime = 0;
                }
            });

            // Si el audio está en reproducción, lo pausamos, si no, lo reproducimos
            if (!audio.paused) {
                audio.pause();
                audio.currentTime = 0;
                caja.style.border = "none";
            } else {
                audio.play();
                caja.style.border = "2px solid orange";
            }
        });
    });

    // Control de sonido del nuevo div .audioMenuSuperior
    const audioMenu = document.querySelector(".audioMenuSuperior audio");
    const iconoMenu = document.querySelector(".audioMenuSuperior .iconos");

    if (iconoMenu && audioMenu) {
        iconoMenu.addEventListener("click", function () {
            if (audioMenu.paused) {
                audioMenu.play();
            } else {
                audioMenu.pause();
            }
        });
    }
});
